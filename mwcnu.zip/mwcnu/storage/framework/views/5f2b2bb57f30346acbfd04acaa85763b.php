

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">

    
    <div class="text-center mb-10">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800">Monitoring Program Kerja MWCNU Karang Tengah</h2>
    </div>

    
    <div class="text-center mb-6">
        <h3 class="text-xl md:text-2xl font-semibold text-emerald-600 uppercase">Program Kerja yang Terjadwal</h3>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $penjadwalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-50 rounded-2xl shadow hover:shadow-md transition p-6">
                <div class="text-center mb-4">
                    <h4 class="text-lg font-semibold text-gray-800"><?php echo e($item->proker->program ?? '-'); ?></h4>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li>
                        <i class="fas fa-calendar-alt text-emerald-500 mr-2"></i>
                        <strong>Mulai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-calendar-check text-emerald-700 mr-2"></i>
                        <strong>Selesai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-sticky-note text-gray-400 mr-2"></i>
                        <strong>Catatan:</strong> <?php echo e($item->catatan ?? '-'); ?>

                    </li>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center text-gray-400 py-10">
                Tidak ada Program kerja
            </div>
        <?php endif; ?>
    </div>

    
    <div class="text-center mt-12 mb-6">
        <h3 class="text-xl md:text-2xl font-semibold text-emerald-600 uppercase">Program Kerja yang Sedang Berjalan</h3>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $berjalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-2xl shadow hover:shadow-md transition p-6">
                <div class="text-center mb-4">
                    <h4 class="text-lg font-semibold text-gray-800"><?php echo e($item->proker->program ?? '-'); ?></h4>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li>
                        <i class="fas fa-calendar-alt text-emerald-500 mr-2"></i>
                        <strong>Mulai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-calendar-check text-emerald-700 mr-2"></i>
                        <strong>Selesai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-sticky-note text-gray-400 mr-2"></i>
                        <strong>Catatan:</strong> <?php echo e($item->catatan ?? '-'); ?>

                    </li>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center text-gray-400 py-10">
                Tidak ada Program kerja
            </div>
        <?php endif; ?>
    </div>

    
    <div class="text-center mt-12 mb-6">
        <h3 class="text-xl md:text-2xl font-semibold text-emerald-600 uppercase">Program Kerja yang Sudah Selesai Dilaksanakan</h3>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-100 rounded-2xl shadow hover:shadow-md transition p-6">
                <div class="text-center mb-4">
                    <h4 class="text-lg font-semibold text-gray-800"><?php echo e($item->proker->program ?? '-'); ?></h4>
                </div>
                <ul class="space-y-2 text-sm text-gray-600">
                    <li>
                        <i class="fas fa-calendar-alt text-emerald-500 mr-2"></i>
                        <strong>Mulai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-calendar-check text-emerald-700 mr-2"></i>
                        <strong>Selesai:</strong> <?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d-m-Y')); ?>

                    </li>
                    <li>
                        <i class="fas fa-sticky-note text-gray-400 mr-2"></i>
                        <strong>Catatan:</strong> <?php echo e($item->catatan ?? '-'); ?>

                    </li>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center text-gray-400 py-10">
                Tidak ada Program kerja
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\ProjectMWCNU\mwcnu\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>